from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class BatteryPackBase(BaseModel):
    name: str
    description: Optional[str] = None
    nominal_voltage: float
    nominal_capacity: float
    cell_count: int
    configuration: str  # e.g., "4S2P"

class BatteryPack(BatteryPackBase):
    id: Optional[str] = None
    created_at: Optional[datetime] = None

class BatteryCellBase(BaseModel):
    pack_id: str
    cell_number: int
    nominal_voltage: float
    nominal_capacity: float
    chemistry: str = "Li-ion"

class BatteryCell(BatteryCellBase):
    id: Optional[str] = None
    created_at: Optional[datetime] = None

class CycleDataBase(BaseModel):
    cell_id: str
    cycle_index: int
    voltage_mean: float
    voltage_min: float
    voltage_max: float
    current_mean: float
    current_min: float
    current_max: float
    temperature_mean: float
    temperature_min: float
    temperature_max: float
    capacity: float
    energy: float

class CycleData(CycleDataBase):
    id: Optional[str] = None
    timestamp: Optional[datetime] = None

class TelemetryDataBase(BaseModel):
    cell_id: str
    voltage: float
    current: float
    temperature: float
    capacity: float
    soc: float  # State of Charge

class TelemetryData(TelemetryDataBase):
    id: Optional[str] = None
    timestamp: Optional[datetime] = None