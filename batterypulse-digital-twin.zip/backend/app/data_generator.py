import numpy as np
import pandas as pd
from typing import List
from dataclasses import dataclass

@dataclass
class CycleDataPoint:
    cycle_index: int
    voltage_mean: float
    voltage_min: float
    voltage_max: float
    current_mean: float
    current_min: float
    current_max: float
    temperature_mean: float
    temperature_min: float
    temperature_max: float
    capacity: float
    energy: float

def generate_synthetic_cycles(
    num_cycles: int = 100,
    temperature_offset: float = 0.0,
    current_scale: float = 1.0,
    nominal_voltage: float = 3.7,
    nominal_capacity: float = 3.0,
    start_cycle: int = 0
) -> List[CycleDataPoint]:
    """
    Generate deterministic synthetic Li-ion battery cycle data
    Based on empirical models of battery aging
    """
    cycles = []
    
    for i in range(start_cycle, start_cycle + num_cycles):
        cycle_idx = i
        
        # Capacity fade: empirical model
        # Capacity loss increases with cycle count and temperature
        base_capacity_loss = cycle_idx * 0.0003  # 0.03% per cycle
        temp_effect = max(0, temperature_offset) * 0.0001  # Additional loss due to high temp
        capacity = nominal_capacity * (1.0 - base_capacity_loss - temp_effect)
        capacity = max(capacity, nominal_capacity * 0.7)  # Cap at 70% of nominal
        
        # Voltage characteristics (simplified)
        voltage_min = nominal_voltage * 0.85  # 3.15V
        voltage_max = nominal_voltage * 1.15  # 4.25V
        voltage_mean = (voltage_min + voltage_max) / 2
        
        # Current characteristics (constant current discharge/charge)
        # Simulate a discharge pulse
        base_current = -2.0  # 2A discharge
        current_mean = base_current * current_scale
        current_min = current_mean * 1.1  # 10% variation
        current_max = current_mean * 0.9
        
        # Temperature characteristics
        base_temp = 25.0  # Room temperature
        temperature_mean = base_temp + temperature_offset
        # Add some cyclic variation
        temp_variation = 2.0 * np.sin(cycle_idx * 0.1)  # 2°C variation
        temperature_mean += temp_variation
        temperature_min = temperature_mean - 3.0
        temperature_max = temperature_mean + 3.0
        
        # Energy calculation (simplified)
        energy = capacity * voltage_mean * 3.6  # Convert Ah*V to Joules (approx)
        
        cycle_data = CycleDataPoint(
            cycle_index=cycle_idx,
            voltage_mean=round(voltage_mean, 3),
            voltage_min=round(voltage_min, 3),
            voltage_max=round(voltage_max, 3),
            current_mean=round(current_mean, 3),
            current_min=round(current_min, 3),
            current_max=round(current_max, 3),
            temperature_mean=round(temperature_mean, 2),
            temperature_min=round(temperature_min, 2),
            temperature_max=round(temperature_max, 2),
            capacity=round(capacity, 3),
            energy=round(energy, 2)
        )
        cycles.append(cycle_data)
    
    return cycles

def generate_pack_cycles(
    pack_config: dict,
    num_cycles: int = 50
) -> dict:
    """Generate cycles for all cells in a pack"""
    # This would generate data for each cell in the pack
    # For simplicity, we'll return data for one cell
    cell_data = generate_synthetic_cycles(
        num_cycles=num_cycles,
        temperature_offset=pack_config.get('temperature_offset', 0.0),
        current_scale=pack_config.get('current_scale', 1.0),
        nominal_voltage=pack_config.get('nominal_voltage', 3.7),
        nominal_capacity=pack_config.get('nominal_capacity', 3.0)
    )
    return {"cell_1": cell_data}

if __name__ == "__main__":
    # Example usage
    cycles = generate_synthetic_cycles(num_cycles=10)
    for cycle in cycles:
        print(f"Cycle {cycle.cycle_index}: Capacity={cycle.capacity}Ah, "
              f"Temp={cycle.temperature_mean}°C, Voltage={cycle.voltage_mean}V")