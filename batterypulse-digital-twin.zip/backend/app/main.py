from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import uuid
from datetime import datetime
import numpy as np
import pandas as pd
from .models import BatteryPack, BatteryCell, CycleData, TelemetryData
from .ml_models import SHEModel, RULModel, AnomalyDetector
from .data_generator import generate_synthetic_cycles
import io

app = FastAPI(title="BatteryPulse API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory storage for demo (replace with database in production)
packs = {}
cells = {}
cycles = {}
telemetry = {}

# Initialize ML models
soh_model = SHEModel()
rul_model = RULModel()
anomaly_detector = AnomalyDetector()

@app.get("/")
async def root():
    return {"message": "BatteryPulse API is running"}

@app.post("/packs/", response_model=dict)
async def create_pack(pack: BatteryPack):
    pack_id = str(uuid.uuid4())
    pack.id = pack_id
    pack.created_at = datetime.now()
    packs[pack_id] = pack
    return {"id": pack_id, **pack.dict()}

@app.get("/packs/{pack_id}", response_model=BatteryPack)
async def get_pack(pack_id: str):
    if pack_id not in packs:
        raise HTTPException(status_code=404, detail="Pack not found")
    return packs[pack_id]

@app.post("/packs/{pack_id}/cells/", response_model=dict)
async def add_cell_to_pack(pack_id: str, cell: BatteryCell):
    if pack_id not in packs:
        raise HTTPException(status_code=404, detail="Pack not found")
    cell_id = str(uuid.uuid4())
    cell.id = cell_id
    cell.pack_id = pack_id
    cell.created_at = datetime.now()
    cells[cell_id] = cell
    return {"id": cell_id, **cell.dict()}

@app.post("/cells/{cell_id}/cycles/", response_model=dict)
async def add_cycle_to_cell(cell_id: str, cycle: CycleData):
    if cell_id not in cells:
        raise HTTPException(status_code=404, detail="Cell not found")
    cycle_id = str(uuid.uuid4())
    cycle.id = cycle_id
    cycle.cell_id = cell_id
    cycle.timestamp = datetime.now()
    cycles[cycle_id] = cycle
    return {"id": cycle_id, **cycle.dict()}

@app.post("/telemetry/", response_model=dict)
async def add_telemetry(telemetry_data: TelemetryData):
    telemetry_id = str(uuid.uuid4())
    telemetry_data.id = telemetry_id
    telemetry_data.timestamp = datetime.now()
    telemetry[telemetry_id] = telemetry_data
    return {"id": telemetry_id, **telemetry_data.dict()}

@app.get("/cells/{cell_id}/soh")
async def get_soh(cell_id: str):
    if cell_id not in cells:
        raise HTTPException(status_code=404, detail="Cell not found")
    # Get recent cycles for SOH prediction
    cell_cycles = [c for c in cycles.values() if c.cell_id == cell_id]
    if len(cell_cycles) < 5:
        raise HTTPException(status_code=400, detail="Insufficient cycle data for SOH prediction")
    # Sort by timestamp and take last 10 cycles
    recent_cycles = sorted(cell_cycles, key=lambda x: x.timestamp)[-10:]
    # Extract features for SOH model
    features = []
    for cycle in recent_cycles:
        features.append([
            cycle.voltage_mean,
            cycle.current_mean,
            cycle.temperature_mean,
            cycle.capacity,
            cycle.cycle_index
        ])
    features = np.array(features)
    soh_score = soh_model.predict(features[-1:])[0]  # Predict for latest cycle
    return {"cell_id": cell_id, "soh": float(soh_score), "timestamp": datetime.now().isoformat()}

@app.get("/cells/{cell_id}/rul")
async def get_rul(cell_id: str):
    if cell_id not in cells:
        raise HTTPException(status_code=404, detail="Cell not found")
    cell_cycles = [c for c in cycles.values() if c.cell_id == cell_id]
    if len(cell_cycles) < 5:
        raise HTTPException(status_code=400, detail="Insufficient cycle data for RUL prediction")
    recent_cycles = sorted(cell_cycles, key=lambda x: x.timestamp)[-10:]
    features = []
    for cycle in recent_cycles:
        features.append([
            cycle.voltage_mean,
            cycle.current_mean,
            cycle.temperature_mean,
            cycle.capacity,
            cycle.cycle_index
        ])
    features = np.array(features)
    rul_score = rul_model.predict(features[-1:])[0]
    return {"cell_id": cell_id, "rul": float(rul_score), "timestamp": datetime.now().isoformat()}

@app.get("/cells/{cell_id}/anomaly-score")
async def get_anomaly_score(cell_id: str):
    if cell_id not in cells:
        raise HTTPException(status_code=404, detail="Cell not found")
    cell_cycles = [c for c in cycles.values() if c.cell_id == cell_id]
    if len(cell_cycles) < 5:
        raise HTTPException(status_code=400, detail="Insufficient cycle data for anomaly detection")
    recent_cycles = sorted(cell_cycles, key=lambda x: x.timestamp)[-10:]
    features = []
    for cycle in recent_cycles:
        features.append([
            cycle.voltage_mean,
            cycle.current_mean,
            cycle.temperature_mean,
            cycle.capacity,
            cycle.cycle_index
        ])
    features = np.array(features)
    anomaly_score = anomaly_detector.predict_score(features[-1:])[0]
    return {"cell_id": cell_id, "anomaly_score": float(anomaly_score), "timestamp": datetime.now().isoformat()}

@app.post("/what-if-simulation/")
async def what_if_simulation(
    pack_id: str,
    temperature_offset: float = 0.0,
    current_scale: float = 1.0,
    cycles_to_simulate: int = 10
):
    if pack_id not in packs:
        raise HTTPException(status_code=404, detail="Pack not found")
    # Get pack cells
    pack_cells = [c for c in cells.values() if c.pack_id == pack_id]
    if not pack_cells:
        raise HTTPException(status_code=400, detail="No cells found in pack")
    # Simulate for first cell in pack (for simplicity)
    cell_id = pack_cells[0].id
    # Generate synthetic cycles with modified parameters
    base_cycles = generate_synthetic_cycles(
        num_cycles=cycles_to_simulate,
        temperature_offset=temperature_offset,
        current_scale=current_scale
    )
    # Predict SOH/RUL for simulated cycles
    results = []
    for cycle_data in base_cycles:
        # In a real implementation, we would feed this to ML models
        # For now, return simulated data with predictions
        soh_pred = soh_model.predict(np.array([[
            cycle_data.voltage_mean,
            cycle_data.current_mean,
            cycle_data.temperature_mean,
            cycle_data.capacity,
            cycle_data.cycle_index
        ]]))[0]
        rul_pred = rul_model.predict(np.array([[
            cycle_data.voltage_mean,
            cycle_data.current_mean,
            cycle_data.temperature_mean,
            cycle_data.capacity,
            cycle_data.cycle_index
        ]]))[0]
        results.append({
            "cycle_index": cycle_data.cycle_index,
            "voltage_mean": cycle_data.voltage_mean,
            "current_mean": cycle_data.current_mean,
            "temperature_mean": cycle_data.temperature_mean,
            "capacity": cycle_data.capacity,
            "predicted_soh": float(soh_pred),
            "predicted_rul": float(rul_pred)
        })
    return {
        "pack_id": pack_id,
        "simulation_params": {
            "temperature_offset": temperature_offset,
            "current_scale": current_scale,
            "cycles_to_simulate": cycles_to_simulate
        },
        "results": results
    }

@app.post("/validate-csv/")
async def validate_csv(file: UploadFile = File(...)):
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="File must be CSV")
    try:
        contents = await file.read()
        df = pd.read_csv(io.StringIO(contents.decode('utf-8')))
        # Expected columns for battery telemetry
        expected_columns = ['timestamp', 'voltage', 'current', 'temperature', 'capacity']
        missing_columns = [col for col in expected_columns if col not in df.columns]
        if missing_columns:
            raise HTTPException(
                status_code=400,
                detail=f"Missing columns: {missing_columns}"
            )
        # Basic data validation
        if df['voltage'].min() < 0 or df['voltage'].max() > 5:
            raise HTTPException(status_code=400, detail="Voltage values out of reasonable range (0-5V)")
        if df['temperature'].min() < -20 or df['temperature'].max() > 60:
            raise HTTPException(status_code=400, detail="Temperature values out of reasonable range (-20-60°C)")
        return {
            "filename": file.filename,
            "rows": len(df),
            "columns": list(df.columns),
            "date_range": {
                "start": df['timestamp'].min() if 'timestamp' in df.columns else None,
                "end": df['timestamp'].max() if 'timestamp' in df.columns else None
            },
            "stats": {
                "voltage_mean": float(df['voltage'].mean()),
                "current_mean": float(df['current'].mean()),
                "temperature_mean": float(df['temperature'].mean()),
                "capacity_mean": float(df['capacity'].mean())
            }
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error processing CSV: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)