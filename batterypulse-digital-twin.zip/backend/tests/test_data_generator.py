import pytest
from app.data_generator import generate_synthetic_cycles, CycleDataPoint

def test_generate_synthetic_cycles():
    cycles = generate_synthetic_cycles(num_cycles=5)
    assert len(cycles) == 5
    assert isinstance(cycles[0], CycleDataPoint)
    assert cycles[0].cycle_index == 0
    # Check that capacity decreases over cycles (with no temp offset)
    capacities = [cycle.capacity for cycle in cycles]
    # Allow for small increases due to modeling, but overall trend should be decreasing
    # Since we start at nominal capacity and apply decay, first few should be very close
    assert capacities[0] >= capacities[-1]  # First capacity >= last capacity

def test_generate_synthetic_cycles_with_temp_offset():
    cycles_normal = generate_synthetic_cycles(num_cycles=10, temperature_offset=0.0)
    cycles_hot = generate_synthetic_cycles(num_cycles=10, temperature_offset=10.0)
    # Higher temperature should lead to faster capacity degradation
    capacity_normal = cycles_normal[-1].capacity
    capacity_hot = cycles_hot[-1].capacity
    assert capacity_hot <= capacity_normal  # Hot cycles should have less or equal capacity

def test_generate_synthetic_cycles_with_current_scale():
    cycles_normal = generate_synthetic_cycles(num_cycles=10, current_scale=1.0)
    cycles_high = generate_synthetic_cycles(num_cycles=10, current_scale=2.0)
    # Higher current scale should affect the current values
    current_normal = abs(cycles_normal[0].current_mean)
    current_high = abs(cycles_high[0].current_mean)
    assert current_high > current_normal  # Higher scale should give higher current magnitude