import pytest
from app.models import BatteryPack, BatteryCell, CycleData, TelemetryData

def test_battery_pack_creation():
    pack = BatteryPack(
        name="Test Pack",
        nominal_voltage=3.7,
        nominal_capacity=3.0,
        cell_count=4,
        configuration="4S1P"
    )
    assert pack.name == "Test Pack"
    assert pack.nominal_voltage == 3.7
    assert pack.nominal_capacity == 3.0
    assert pack.cell_count == 4
    assert pack.configuration == "4S1P"

def test_battery_cell_creation():
    cell = BatteryCell(
        pack_id="pack_1",
        cell_number=1,
        nominal_voltage=3.7,
        nominal_capacity=3.0
    )
    assert cell.pack_id == "pack_1"
    assert cell.cell_number == 1
    assert cell.nominal_voltage == 3.7
    assert cell.nominal_capacity == 3.0

def test_cycle_data_creation():
    cycle = CycleData(
        cell_id="cell_1",
        cycle_index=1,
        voltage_mean=3.7,
        voltage_min=3.0,
        voltage_max=4.2,
        current_mean=-2.0,
        current_min=-2.2,
        current_max=-1.8,
        temperature_mean=25.0,
        temperature_min=24.0,
        temperature_max=26.0,
        capacity=2.9,
        energy=10.7
    )
    assert cycle.cell_id == "cell_1"
    assert cycle.cycle_index == 1
    assert cycle.voltage_mean == 3.7
    assert cycle.capacity == 2.9

def test_telemetry_data_creation():
    telemetry = TelemetryData(
        cell_id="cell_1",
        voltage=3.7,
        current=-2.0,
        temperature=25.0,
        capacity=2.9,
        soc=0.8
    )
    assert telemetry.cell_id == "cell_1"
    assert telemetry.voltage == 3.7
    assert telemetry.soc == 0.8