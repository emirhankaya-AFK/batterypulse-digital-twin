import pytest
import numpy as np
from app.ml_models import SHEModel, RULModel, AnomalyDetector

def test_she_model_predict():
    model = SHEModel()
    # Test with dummy data
    X = np.array([[3.7, -2.0, 25.0, 2.9, 100]])  # voltage, current, temp, capacity, cycle
    pred = model.predict(X)
    assert isinstance(pred, np.ndarray)
    assert len(pred) == 1
    assert 0.0 <= pred[0] <= 1.0  # SOH should be between 0 and 1

def test_rul_model_predict():
    model = RULModel()
    X = np.array([[3.7, -2.0, 25.0, 2.9, 100]])
    pred = model.predict(X)
    assert isinstance(pred, np.ndarray)
    assert len(pred) == 1
    assert pred[0] >= 0  # RUL should be non-negative

def test_anomaly_detector_predict_score():
    detector = AnomalyDetector()
    # Normal values
    X_normal = np.array([[3.7, -2.0, 25.0]])
    score_normal = detector.predict_score(X_normal)
    assert isinstance(score_normal, np.ndarray)
    assert len(score_normal) == 1
    assert 0.0 <= score_normal[0] <= 1.0
    
    # Abnormal voltage
    X_high_voltage = np.array([[5.0, -2.0, 25.0]])  # Voltage too high
    score_high = detector.predict_score(X_high_voltage)
    assert score_high[0] > score_normal[0]  # Should have higher anomaly score
    
    # Abnormal temperature
    X_high_temp = np.array([[3.7, -2.0, 80.0]])  # Temperature too high
    score_high_temp = detector.predict_score(X_high_temp)
    assert score_high_temp[0] > score_normal[0]  # Should have higher anomaly score