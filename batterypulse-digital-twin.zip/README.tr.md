# BatteryPulse: Batarya Dijital İkiz Platformu

BatteryPulse, lityum-iyon batarya paketleri için gerçek zamanlı izleme, tahmin ve simulasyon özelliklerini sağlayan kapsamlı bir batarya dijital ikiz platformudur. Platform, fizik tabanlı modellerle makine öğrenimini birleştirerek Batarya Sağlığı Durumu (SOH), Kullanım Ömrü (RUL) tahmini ve batarya performansındaki anomali tespiti yapar.

## Özellikler

- **Gerçek Zamanlı İzleme**: Canlı telemetri verisi görselleştirme
- **SOH Tahmini**: Makine öğrenimi tabanlı Batarya Sağlığı Durumu tahmini
- **RUL Tahmini**: Kullanım Ömrü öngörüsü
- **Anomali Tespiti**: Erken arıza tespiti için gerçek zamanlı anomali puanlaması
- **Ne-Senaryo Simülasyonu**: Farklı koşullarda batarya davranışını simülasyon
- **Veri Doğrulama**: Harici veri için CSV yükleme ve doğrulama
- **RESTful API**: Entegrasyon için kapsamlı API
- **Etkileşimli Kontrol Paneli**: Kolay veri görselleştirme için React tabanlı UI

## Mimari

```
┌─────────────────┐    ┌──────────────────┐    ┌────────────────────┐
│   Frontend      │    │    Backend API   │    │     ML Models      │
│ (React/Vite/TS) │◄─►│ (FastAPI/Python) │◄─►│ (Scikit-learn/NumPy) │
└─────────────────┘    └──────────────────┘    └────────────────────┘
        │                         │                         │
        │                         ▼                         │
        │              ┌────────────────────┐                │
        │              │   Sentetik Veri    │                │
        │              │   Üretici          │                │
        │              └────────────────────┘                │
        │                         │                         │
        ▼                         ▼                         ▼
┌─────────────────┐    ┌──────────────────┐    ┌────────────────────┐
│   Docker        │    │   Kubernetes     │    │      CI/CD         │
│   Compose       │    │   Manifests      │    │ (GitHub Actions)   │
└─────────────────┘    └──────────────────┘    └────────────────────┘
```

## Başlangıç

### Ön Gereklilikler

- Docker ve Docker Compose
- Git (depo klonlamak için)

### Kurulum

1. Depoyu klonlayın:
   ```bash
   git clone <depo-url>
   cd batterypulse-digital-twin
   ```

2. Hizmetleri başlatın:
   ```bash
   make up
   ```

3. Uygulamalara erişin:
   - Frontend Kontrol Paneli: http://localhost:3000
   - Backend API: http://localhost:8000
   - API Belgeleri: http://localhost:8000/docs

### Geliştirme

```bash
# Arka planı geliştirme modunda başlat
make dev-backend

# Ön yüzü geliştirme modunda başlat
make dev-frontend

# Testleri çalıştır
make test

# Kod denetimi yap
make lint

# Kodu biçimlendir
make format
```

## API Uç Noktaları

### Batarya Yönetimi
- `POST /packs/` - Yeni batarya paketi oluştur
- `GET /packs/{pack_id}` - Batarya paketi detaylarını al
- `POST /packs/{pack_id}/cells/` - Pakete hücre ekle
- `GET /cells/{cell_id}` - Hücre detaylarını al

### Telemetri ve Döngüler
- `POST /telemetry/` - Telemetri veri noktası ekle
- `POST /cells/{cell_id}/cycles/` - Hücreye döngü verisi ekle
- `GET /cells/{cell_id}/soh` - Batarya Sağlığı Durumu tahmini al
- `GET /cells/{cell_id}/rul` - Kullanım Ömrü tahmini al
- `GET /cells/{cell_id}/anomaly-score` - Anomali puanı al

### Simülasyon ve Analiz
- `POST /what-if-simulation/` - Ne-senaryo simülasyonu çalıştır
- `POST /validate-csv/` - CSV yüklemesini doğrula ve işle

## Model Açıklamaları

### Batarya Sağlığı Durumu (SOH) Modeli
Nominal kapasiteye göre mevcut kapasiteyi tahmin eder ve şunları kullanır:
- Voltaj özellikleri
- Akım profilleri
- Sıcaklık etkileri
- Döngü sayısı

### Kullanım Ömrü (RUL) Modeli
Bataryanın %80 SOH'a ulaşana kadar kalan döngü sayısını tahmin eder ve şunları temel alır:
- Tarihsel bozulma eğilimleri
- Çalışma koşulları (sıcaklık, akım)
- Kullanım paternleri

### Anomali Tespiti Modeli
Abnormal batarya davranışını şu eşik değerleri kullanarak tanımlar:
- Voltaj eşik değerleri (2.5V - 4.2V)
- Akım eşik değerleri (-5A ile 5A)
- Sıcaklık eşik değerleri (-20°C ile 60°C)
- Normal paternlerden istatistiksel sapma

## Veri Modelleri

### Batarya Paketi
- `name`: Paket tanımlayıcısı
- `nominal_voltage`: Toplam paket voltajı
- `nominal_capacity`: Toplam paket kapasitesi (Ah)
- `cell_count`: Hücre sayısı
- `configuration`: Seri/paralel yapılandırması (örn: "4S2P")

### Batarya Hücresi
- `pack_id`: İlişkili paket tanımlayıcısı
- `cell_number`: Paket içindeki hücre numarası
- `nominal_voltage`: Nominal hücre voltajı (V)
- `nominal_capacity`: Nominal hücre kapasitesi (Ah)
- `chemistry`: Batarya kimyası (varsayılan: Li-ion)

### Döngü Verisi
- `cell_id`: İlişkili hücre tanımlayıcısı
- `cycle_index`: Döngü numarası
- `voltage_mean/min/max`: Voltaj istatistikleri (V)
- `current_mean/min/max`: Akım istatistikleri (A)
- `temperature_mean/min/max`: Sıcaklık istatistikleri (°C)
- `capacity`: Descaj kapasitesi (Ah)
- `energy`: Enerji akımı (J)

### Telemetri Verisi
- `cell_id`: İlişkili hücre tanımlayıcısı
- `voltage`: Anlık voltaj (V)
- `current`: Anlık akım (A)
- `temperature`: Anlık sıcaklık (°C)
- `capacity`: Mevcut kapasite (Ah)
- `soc`: Şarj Durumu (0-1)

## Dağıtım

### Docker Compose
Platform, geliştirme ve test için Docker Compose kullanılarak dağıtılabilir:
```bash
docker-compose up -d
```

### Kubernetes
Üretim dağıtımı manifests `k8s/` klasöründe mevcuttur:
```bash
kubectl apply -f k8s/
```

## Örnek Veri Üretimi

Test ve gösterim için örnek veri üretin:
```bash
python sample_data/generate_sample_data.py
```

Bu komut, örnek JSON ve CSV dosyalarını `sample_data/` klasörüne oluşturur.

## Lisans

MIT Lisansı - detaylar için LICENSE dosyasına bakın.

## İletişim

Destek ve sorular için GitHub deposunda bir issue açın.