# BatteryPulse API Documentation

## Base URL

```
http://localhost:8000/api
```

All API endpoints are prefixed with `/api`. The interactive API documentation is available at `/docs` (Swagger UI) and `/redoc` (ReDoc).

## Authentication

*Note: Authentication is not implemented in this version. In production, JWT-based authentication would be required.*

## Error Handling

All endpoints return standard HTTP status codes:
- 200: Success
- 201: Created
- 400: Bad Request
- 404: Not Found
- 500: Internal Server Error

Error responses follow this format:
```json
{
  "detail": "Error description"
}
```

## Endpoints

### Battery Pack Management

#### Create a Battery Pack
```
POST /packs/
```

Creates a new battery pack.

**Request Body:**
```json
{
  "name": "string",
  "description": "string (optional)",
  "nominal_voltage": "number",
  "nominal_capacity": "number",
  "cell_count": "integer",
  "configuration": "string"
}
```

**Response:**
```json
{
  "id": "string (uuid)",
  "name": "string",
  "description": "string",
  "nominal_voltage": "number",
  "nominal_capacity": "number",
  "cell_count": "integer",
  "configuration": "string",
  "created_at": "string (datetime)"
}
```

#### Get Battery Pack Details
```
GET /packs/{pack_id}
```

Retrieves details for a specific battery pack.

**Path Parameters:**
- `pack_id`: UUID of the battery pack

**Response:** Same as creation response

### Battery Cell Management

#### Add Cell to Pack
```
POST /packs/{pack_id}/cells/
```

Adds a new cell to a battery pack.

**Path Parameters:**
- `pack_id`: UUID of the parent battery pack

**Request Body:**
```json
{
  "cell_number": "integer",
  "nominal_voltage": "number",
  "nominal_capacity": "number",
  "chemistry": "string (optional, default: Li-ion)"
}
```

**Response:**
```json
{
  "id": "string (uuid)",
  "pack_id": "string (uuid)",
  "cell_number": "integer",
  "nominal_voltage": "number",
  "nominal_capacity": "number",
  "chemistry": "string",
  "created_at": "string (datetime)"
}
```

### Telemetry and Cycle Data

#### Add Telemetry Data
```
POST /telemetry/
```

Adds a telemetry data point for a cell.

**Request Body:**
```json
{
  "cell_id": "string (uuid)",
  "voltage": "number",
  "current": "number",
  "temperature": "number",
  "capacity": "number",
  "soc": "number (0-1)"
}
```

**Response:**
```json
{
  "id": "string (uuid)",
  "cell_id": "string (uuid)",
  "voltage": "number",
  "current": "number",
  "temperature": "number",
  "capacity": "number",
  "soc": "number",
  "timestamp": "string (datetime)"
}
```

#### Add Cycle Data
```
POST /cells/{cell_id}/cycles/
```

Adds cycle data for a specific cell.

**Path Parameters:**
- `cell_id`: UUID of the cell

**Request Body:**
```json
{
  "cycle_index": "integer",
  "voltage_mean": "number",
  "voltage_min": "number",
  "voltage_max": "number",
  "current_mean": "number",
  "current_min": "number",
  "current_max": "number",
  "temperature_mean": "number",
  "temperature_min": "number",
  "temperature_max": "number",
  "capacity": "number",
  "energy": "number"
}
```

**Response:**
```json
{
  "id": "string (uuid)",
  "cell_id": "string (uuid)",
  "cycle_index": "integer",
  "voltage_mean": "number",
  "voltage_min": "number",
  "voltage_max": "number",
  "current_mean": "number",
  "current_min": "number",
  "current_max": "number",
  "temperature_mean": "number",
  "temperature_min": "number",
  "temperature_max": "number",
  "capacity": "number",
  "energy": "number",
  "timestamp": "string (datetime)"
}
```

### Prediction Endpoints

#### Get State of Health (SOH)
```
GET /cells/{cell_id}/soh
```

Returns the predicted State of Health for a cell.

**Path Parameters:**
- `cell_id`: UUID of the cell

**Response:**
```json
{
  "cell_id": "string (uuid)",
  "soh": "number (0-1)",
  "timestamp": "string (datetime)"
}
```

#### Get Remaining Useful Life (RUL)
```
GET /cells/{cell_id}/rul
```

Returns the predicted Remaining Useful Life for a cell.

**Path Parameters:**
- `cell_id`: UUID of the cell

**Response:**
```json
{
  "cell_id": "string (uuid)",
  "rul": "number (cycles)",
  "timestamp": "string (datetime)"
}
```

#### Get Anomaly Score
```
GET /cells/{cell_id}/anomaly-score
```

Returns the anomaly score for a cell.

**Path Parameters:**
- `cell_id`: UUID of the cell

**Response:**
```json
{
  "cell_id": "string (uuid)",
  "anomaly_score": "number (0-1, higher is more anomalous)",
  "timestamp": "string (datetime)"
}
```

### Simulation and Analysis

#### What-If Simulation
```
POST /what-if-simulation/
```

Runs a what-if simulation for a battery pack under modified conditions.

**Request Body:**
```json
{
  "pack_id": "string (uuid)",
  "temperature_offset": "number (optional, default: 0.0)",
  "current_scale": "number (optional, default: 1.0)",
  "cycles_to_simulate": "integer (optional, default: 10)"
}
```

**Response:**
```json
{
  "pack_id": "string (uuid)",
  "simulation_params": {
    "temperature_offset": "number",
    "current_scale": "number",
    "cycles_to_simulate": "integer"
  },
  "results": [
    {
      "cycle_index": "integer",
      "voltage_mean": "number",
      "current_mean": "number",
      "temperature_mean": "number",
      "capacity": "number",
      "predicted_soh": "number",
      "predicted_rul": "number"
    }
  ]
}
```

#### Validate CSV Upload
```
POST /validate-csv/
```

Validates and processes a CSV file containing battery telemetry data.

**Request:**
- `file`: CSV file with columns: timestamp, voltage, current, temperature, capacity, soc (optional)

**Response:**
```json
{
  "filename": "string",
  "rows": "integer",
  "columns": ["string"],
  "date_range": {
    "start": "string (datetime)",
    "end": "string (datetime)"
  },
  "stats": {
    "voltage_mean": "number",
    "current_mean": "number",
    "temperature_mean": "number",
    "capacity_mean": "number"
  }
}
```

## Data Models

### BatteryPack
- `id`: string (uuid)
- `name`: string
- `description`: string (optional)
- `nominal_voltage`: number
- `nominal_capacity`: number
- `cell_count`: integer
- `configuration`: string
- `created_at`: string (datetime)

### BatteryCell
- `id`: string (uuid)
- `pack_id`: string (uuid)
- `cell_number`: integer
- `nominal_voltage`: number
- `nominal_capacity`: number
- `chemistry`: string
- `created_at`: string (datetime)

### CycleData
- `id`: string (uuid)
- `cell_id`: string (uuid)
- `cycle_index`: integer
- `voltage_mean`: number
- `voltage_min`: number
- `voltage_max`: number
- `current_mean`: number
- `current_min`: number
- `current_max`: number
- `temperature_mean`: number
- `temperature_min`: number
- `temperature_max`: number
- `capacity`: number
- `energy`: number
- `timestamp`: string (datetime)

### TelemetryData
- `id`: string (uuid)
- `cell_id`: string (uuid)
- `voltage`: number
- `current`: number
- `temperature`: number
- `capacity`: number
- `soc`: number (0-1)
- `timestamp`: string (datetime)

## Usage Examples

### Creating a Battery Pack
```bash
curl -X POST 'http://localhost:8000/api/packs/' \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "EV Battery Pack",
    "nominal_voltage": 14.8,
    "nominal_capacity": 6.0,
    "cell_count": 4,
    "configuration": "4S1P"
  }'
```

### Adding Telemetry Data
```bash
curl -X POST 'http://localhost:8000/api/telemetry/' \
  -H 'Content-Type: application/json' \
  -d '{
    "cell_id": "123e4567-e89b-12d3-a456-426614174000",
    "voltage": 3.7,
    "current": -2.0,
    "temperature": 25.0,
    "capacity": 2.9,
    "soc": 0.8
  }'
```

### Getting SOH Prediction
```bash
curl -X GET 'http://localhost:8000/api/cells/123e4567-e89b-12d3-a456-426614174000/soh'
```

### Running What-If Simulation
```bash
curl -X POST 'http://localhost:8000/api/what-if-simulation/' \
  -H 'Content-Type: application/json' \
  -d '{
    "pack_id": "123e4567-e89b-12d3-a456-426614174000",
    "temperature_offset": 5.0,
    "current_scale": 1.2,
    "cycles_to_simulate": 10
  }'
```