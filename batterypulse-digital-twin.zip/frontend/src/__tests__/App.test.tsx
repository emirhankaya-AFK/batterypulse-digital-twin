import { render, screen } from '@testing-library/react';
import App from '../App';

test('renders headline', () => {
  render(<App />);
  const headingElement = screen.getByRole('heading', { name: /batterypulse dashboard/i });
  expect(headingElement).toBeInTheDocument();
});