import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import axios from 'axios';

const API_BASE_URL = '/api';

function App() {
  const [sohData, setSohData] = useState<Array<{name: string, value: number}>>([]);
  const [rulData, setRulData] = useState<Array<{name: string, value: number}>>([]);
  const [anomalyData, setAnomalyData] = useState<Array<{name: string, value: number}>>([]);
  const [cellId, setCellId] = useState<string>('cell_1');
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetchCellData();
  }, [cellId]);

  const fetchCellData = async () => {
    setLoading(true);
    try {
      // Fetch SOH
      const sohResponse = await axios.get(`${API_BASE_URL}/cells/${cellId}/soh`);
      const sohValue = sohResponse.data.soh;
      setSohData(prev => [...prev.slice(-9), {name: `Cycle ${sohResponse.data.timestamp}`, value: sohValue}]);
      
      // Fetch RUL
      const rulResponse = await axios.get(`${API_BASE_URL}/cells/${cellId}/rul`);
      const rulValue = rulResponse.data.rul;
      setRulData(prev => [...prev.slice(-9), {name: `Cycle ${rulResponse.data.timestamp}`, value: rulValue}]);
      
      // Fetch Anomaly Score
      const anomalyResponse = await axios.get(`${API_BASE_URL}/cells/${cellId}/anomaly-score`);
      const anomalyValue = anomalyResponse.data.anomaly_score;
      setAnomalyData(prev => [...prev.slice(-9), {name: `Cycle ${anomalyResponse.data.timestamp}`, value: anomalyValue}]);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleWhatIfSimulation = async () => {
    try {
      const response = await axios.post(`${API_BASE_URL}/what-if-simulation/`, {
        pack_id: "pack_1", // In a real app, this would be selected
        temperature_offset: 5.0,
        current_scale: 1.2,
        cycles_to_simulate: 10
      });
      console.log('Simulation results:', response.data);
      // In a real app, we would update charts with simulation results
    } catch (error) {
      console.error('Error running simulation:', error);
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">BatteryPulse Dashboard</h1>
      
      <div className="mb-4">
        <label className="mr-2">Cell ID: </label>
        <input
          type="text"
          value={cellId}
          onChange={(e) => setCellId(e.target.value)}
          className="border rounded px-2 py-1"
        />
        <button 
          onClick={fetchCellData}
          className="ml-2 bg-blue-500 text-white px-3 py-1 rounded"
        >
          Load Cell Data
        </button>
        <button 
          onClick={handleWhatIfSimulation}
          className="ml-2 bg-green-500 text-white px-3 py-1 rounded"
        >
          Run What-If Simulation
        </button>
      </div>

      {loading ? (
        <p className="text-center">Loading...</p>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            <div className="border rounded p-4">
              <h2 className="font-bold mb-2">State of Health (SOH)</h2>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={sohData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="value" stroke="#8884d8" />
                </LineChart>
              </ResponsiveContainer>
              <p className="mt-2 text-center">{sohData.length > 0 ? `${(sohData[sohData.length-1].value * 100).toFixed(1)}%` : 'N/A'}</p>
            </div>
            
            <div className="border rounded p-4">
              <h2 className="font-bold mb-2">Remaining Useful Life (RUL)</h2>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={rulData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="value" stroke="#82ca9d" />
                </LineChart>
              </ResponsiveContainer>
              <p className="mt-2 text-center">{rulData.length > 0 ? `${rulData[rulData.length-1].value.toFixed(0)} cycles` : 'N/A'}</p>
            </div>
            
            <div className="border rounded p-4">
              <h2 className="font-bold mb-2">Anomaly Score</h2>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={anomalyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="value" stroke="#ff9f43" />
                </LineChart>
              </ResponsiveContainer>
              <p className="mt-2 text-center">{anomalyData.length > 0 ? anomalyData[anomalyData.length-1].value.toFixed(3) : 'N/A'}</p>
            </div>
          </div>
          
          <div className="border rounded p-4">
            <h2 className="font-bold mb-4">Telemetry Data (Sample)</h2>
            <p>In a real implementation, this would show live telemetry data from the battery pack.</p>
            <p>Current cell: {cellId}</p>
          </div>
        </>
      )}
    </div>
  );
}

export default App;