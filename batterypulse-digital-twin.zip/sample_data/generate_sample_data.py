"""
Sample data generator for BatteryPulse
Creates sample battery data for testing and demonstration
"""
import json
import csv
from datetime import datetime, timedelta
from backend.app.data_generator import generate_synthetic_cycles
from backend.app.models import BatteryPack, BatteryCell

def generate_sample_pack_data():
    """Generate a sample battery pack with cells and cycle data"""
    # Create a sample pack
    pack = BatteryPack(
        name="EV Battery Pack",
        description="Sample 4S2P Li-ion battery pack for electric vehicle",
        nominal_voltage=3.7 * 4,  # 4S
        nominal_capacity=3.0 * 2, # 2P
        cell_count=8,
        configuration="4S2P"
    )
    
    # Create cells for the pack
    cells = []
    for i in range(1, 9):  # 8 cells
        cell = BatteryCell(
            pack_id="sample_pack_id",
            cell_number=i,
            nominal_voltage=3.7,
            nominal_capacity=3.0,
            chemistry="Li-ion"
        )
        cells.append(cell)
    
    # Generate cycle data for each cell
    all_cycles = {}
    for cell in cells:
        cycles = generate_synthetic_cycles(
            num_cycles=50,
            temperature_offset=2.0,  # Slightly elevated temperature
            current_scale=1.0,
            nominal_voltage=3.7,
            nominal_capacity=3.0
        )
        all_cycles[cell.cell_number] = cycles
    
    return {
        "pack": pack.dict(),
        "cells": [cell.dict() for cell in cells],
        "cycles": all_cycles
    }

def save_as_json(data, filename):
    """Save data as JSON file"""
    # Convert datetime objects to strings
    def convert_datetime(obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        raise TypeError(f"Object of type {type(obj)} is not JSON serializable")
    
    with open(filename, 'w') as f:
        json.dump(data, f, default=convert_datetime, indent=2)

def save_cycles_as_csv(cycles_data, filename):
    """Save cycle data as CSV file"""
    with open(filename, 'w', newline='') as csvfile:
        fieldnames = [
            'cell_number', 'cycle_index', 'voltage_mean', 'voltage_min', 'voltage_max',
            'current_mean', 'current_min', 'current_max', 'temperature_mean',
            'temperature_min', 'temperature_max', 'capacity', 'energy'
        ]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        
        for cell_number, cycles in cycles_data.items():
            for cycle in cycles:
                row = {
                    'cell_number': cell_number,
                    'cycle_index': cycle.cycle_index,
                    'voltage_mean': cycle.voltage_mean,
                    'voltage_min': cycle.voltage_min,
                    'voltage_max': cycle.voltage_max,
                    'current_mean': cycle.current_mean,
                    'current_min': cycle.current_min,
                    'current_max': cycle.current_max,
                    'temperature_mean': cycle.temperature_mean,
                    'temperature_min': cycle.temperature_min,
                    'temperature_max': cycle.temperature_max,
                    'capacity': cycle.capacity,
                    'energy': cycle.energy
                }
                writer.writerow(row)

def generate_sample_csv_telemetry():
    """Generate sample CSV telemetry data for upload testing"""
    telemetry_data = []
    base_time = datetime.now() - timedelta(hours=1)
    
    for i in range(100):
        timestamp = base_time + timedelta(seconds=i*10)
        voltage = 3.7 + (0.1 * np.sin(i * 0.1))  # Small oscillation
        current = -2.0 + (0.5 * np.sin(i * 0.05))  # Varying discharge
        temperature = 25.0 + (2.0 * np.sin(i * 0.02))  # Slow temp variation
        capacity = 2.9 - (i * 0.001)  # Slow capacity fade
        
        telemetry_data.append({
            'timestamp': timestamp.isoformat(),
            'voltage': round(voltage, 3),
            'current': round(current, 3),
            'temperature': round(temperature, 2),
            'capacity': round(capacity, 3),
            'soc': round(max(0.1, min(1.0, 0.9 - i*0.008)), 3)
        })
    
    return telemetry_data

if __name__ == "__main__":
    import numpy as np
    
    print("Generating sample BatteryPulse data...")
    
    # Generate pack and cell data
    sample_data = generate_sample_pack_data()
    
    # Save as JSON
    save_as_json(sample_data, "sample_data/battery_pack_sample.json")
    print("Saved pack data to sample_data/battery_pack_sample.json")
    
    # Save cycles as CSV
    save_cycles_as_csv(sample_data["cycles"], "sample_data/cycle_data_sample.csv")
    print("Saved cycle data to sample_data/cycle_data_sample.csv")
    
    # Generate and save telemetry CSV
    telemetry_data = generate_sample_csv_telemetry()
    with open("sample_data/telemetry_sample.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=['timestamp', 'voltage', 'current', 'temperature', 'capacity', 'soc'])
        writer.writeheader()
        writer.writerows(telemetry_data)
    print("Saved telemetry data to sample_data/telemetry_sample.csv")
    
    print("Sample data generation complete!")